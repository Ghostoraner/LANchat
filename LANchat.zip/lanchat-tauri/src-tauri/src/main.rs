#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    lanchat_tauri_lib::run();
}